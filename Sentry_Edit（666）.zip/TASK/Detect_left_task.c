#include "Detect_left_task.h"
#include "cmsis_os.h"
#include "Shoot_task.h"
#include "Buzzer_task.h"
#include "math.h"
#include "remote_control.h"
#include "Gimbal_task.h"
#include "Information_task.h"




int left_block_cnt=0,left_block_flag=0,left_protect_cnt=0;

void Detect_left_task(void const *pvParameters)
{

    osDelay(500);
    while (!Gimbal_All_Element_Init_Finish) { osDelay(10); }



    while (RC->rc.s[1] != 1) { osDelay(10); }


    while(1)
    {

            if (RC->rc.s[1] == 1)
            {
                Send_motor.Left.speed_set=120;

                if(Send_motor.Left.motor_current>9800)
                    left_block_cnt++;
                else
                    left_block_cnt=0;

                if(left_block_cnt>40)
                    left_block_flag=1;

                if(left_block_flag==1)
                {
                    Send_motor.Left.speed_set=-30;
                    left_protect_cnt++;

                    if(left_protect_cnt==20)
                    {
                        left_block_flag=0;
                        left_protect_cnt=0;
                    }
                }
            }
            else
            {
                Send_motor.Left.speed_set=0;
                left_block_flag=0;
                left_protect_cnt=0;
                left_block_cnt=0;
            }


        osDelay(10);
}


}





