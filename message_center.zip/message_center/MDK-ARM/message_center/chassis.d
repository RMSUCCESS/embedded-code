message_center\chassis.o: ..\application\Chassis\Chassis.c
message_center\chassis.o: ..\application\Chassis\chassis.h
