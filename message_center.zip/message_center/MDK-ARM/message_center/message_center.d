message_center\message_center.o: ..\modules\message_center\message_center.c
message_center\message_center.o: ..\modules\message_center\message_center.h
message_center\message_center.o: D:\keil5\ARM\ARMCC\Bin\..\include\stdint.h
message_center\message_center.o: D:\keil5\ARM\ARMCC\Bin\..\include\stdlib.h
message_center\message_center.o: D:\keil5\ARM\ARMCC\Bin\..\include\string.h
