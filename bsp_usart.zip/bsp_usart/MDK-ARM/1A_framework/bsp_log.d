1a_framework\bsp_log.o: ..\bsp\log\bsp_log.c
1a_framework\bsp_log.o: ..\bsp\log\bsp_log.h
1a_framework\bsp_log.o: D:\keil5\ARM\ARMCC\Bin\..\include\stdint.h
1a_framework\bsp_log.o: D:\keil5\ARM\ARMCC\Bin\..\include\string.h
