1a_framework\daemon.o: ..\modules\daemon\daemon.c
1a_framework\daemon.o: ..\modules\daemon\daemon.h
1a_framework\daemon.o: D:\keil5\ARM\ARMCC\Bin\..\include\stdint.h
1a_framework\daemon.o: D:\keil5\ARM\ARMCC\Bin\..\include\string.h
1a_framework\daemon.o: D:\keil5\ARM\ARMCC\Bin\..\include\stdlib.h
