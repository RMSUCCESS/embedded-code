/**
******************************************************************************
 * @file	bsp_led.c
 * @author  L J
 * @version V1.0
 * @date    2025/11/29
 * @brief
 ******************************************************************************
 * @attention
 *
 ******************************************************************************
 */
#include "mod_imu.h"
#include "bsp_spi.h"


IMU_DataTypeDef IMU_DATA;
SPIInstance *my_spi_device;
 
/**
 * @brief SPI��ʼ���ص�����
 *
 */
void my_spi_callback(SPIInstance *spi_ins)
{
    if(spi_ins->rx_buffer != NULL) {
//      printf("Received %d bytes\n", spi_ins->rx_size);
        for(int i = 0; i < spi_ins->rx_size; i++) {
//          printf("Data[%d]: 0x%02X\n", i, spi_ins->rx_buffer[i]);
        }
    }
}

/**
 * @brief SPI_��ʼ���豸
 *
 */
void SPI_Init_Device(void)
{
    SPI_Init_Config_s spi_config = {
        .spi_handle = &hspi2,           
        .GPIOx = GPIOB,                 
        .cs_pin = GPIO_PIN_12,           
        .spi_work_mode = SPI_DMA_MODE,  
        .callback = my_spi_callback,    
        .id = 0                         
    };
    my_spi_device = SPIRegister(&spi_config);
    if(my_spi_device == NULL) {
        Error_Handler();  
    }
	IMU_DATA.iwfg_flag = 0;
}
/**
 * @brief uint8_t����ƴ��float����
 *
 * @param SPI_RECEIVED_DATA uint8_t����
 * @param MSB_LSB                  λ�� 
 */ 
static float UINT8_T_TO_FLOAT (uint8_t * SPI_RECEIVED_DATA , int MSB_LSB )
{
	uint32_t temp = 0;
    float result;
	
	if(MSB_LSB == LSB)
	{
		 temp = ((uint32_t)SPI_RECEIVED_DATA[3] << 24) |
				((uint32_t)SPI_RECEIVED_DATA[2] << 16) |
				((uint32_t)SPI_RECEIVED_DATA[1] << 8)  |
				 (uint32_t)SPI_RECEIVED_DATA[0];
	}
	else 
	{
		temp = ((uint32_t)SPI_RECEIVED_DATA[0] << 24)  |
               ((uint32_t)SPI_RECEIVED_DATA[1] << 16)  |
			   ((uint32_t)SPI_RECEIVED_DATA[2] << 8)   |
		        (uint32_t)SPI_RECEIVED_DATA[3];
	}
	memcpy(&result, &temp, sizeof(result));
	return result;
}
/**
 * @brief �������ݽ���
 *
 * @param FLOAT_DATACAL float����
 * @param SPI_RECEIVED  uint8_t����    
 * @param MSB_LSB       λ��                  
 */ 
static void SPI_DATACAL (float FLOAT_DATACAL[],uint8_t SPI_RECEIVED[],int MSB_LSB)
{
	int i ;
	int start_state;
	
	for(i=0;i<(sizeof(IMU_DATA.imu_data)/sizeof(float));i++)
	{
		start_state = i * CALDATA_LEN + HEAD_LEN ;
		FLOAT_DATACAL[i] = UINT8_T_TO_FLOAT(&SPI_RECEIVED[start_state],MSB_LSB); 
	}
}	 
/**
 * @brief IMU���ݻ�ȡ�����
 *              
 */
IMU_DataTypeDef IMU_GET_DATA(void)
{
	  SPIRecv(my_spi_device,IMU_DATA.imu_spi_received,40);
	  if(IMU_DATA.imu_spi_received[1+HEAD_LEN]!= 0x00)
	  {
		  if(!IMU_DATA.iwfg_flag)
		  {
				MX_IWDG_Init();           //12.5����ι��
				IMU_DATA.iwfg_flag = 1;
		  }
		  if(IMU_DATA.imu_spi_received[0] == 0x00 && IMU_DATA.imu_spi_received[1] == 0x80 
				&& IMU_DATA.imu_spi_received[38] == 0x00 && IMU_DATA.imu_spi_received[39] ==0x7f )
		  {
					SPI_DATACAL(IMU_DATA.imu_data,IMU_DATA.imu_spi_received,MSB);
					HAL_IWDG_Refresh(&hiwdg);
					return IMU_DATA;
		  } 
	  }
	  
}
