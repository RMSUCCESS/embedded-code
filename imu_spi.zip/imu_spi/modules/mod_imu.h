#ifndef __MOD_IMU_H__
#define __MOD_IMU_H__

#include "stdio.h"
#include "string.h"
#include <stdint.h>
#include "spi.h"
#include "iwdg.h"

#define CALDATA_LEN 4
#define HEAD_LEN    2
#define TAIL_LEN    2

typedef struct 
{
	uint8_t imu_spi_received[40];
	float   imu_data[9];
	uint8_t iwfg_flag;
}IMU_DataTypeDef;

enum SEQUENCE
{
	LSB = 0,
	MSB,
	
};
void SPI_Init_Device(void);
IMU_DataTypeDef IMU_GET_DATA(void);
#endif
