#include "PID.h"

//important 以实现效果优先，当调试的参数无法满足要求，再增加算法处理
//微分先行和滤波推荐一起使用，微分先行在测量上，滤波在微分上输出
//微分先行用于适合于给定值频繁变化的场合，可以避免给定值变化时可能引起的系统振荡
//微分滤波用于抑制高频噪声
//dynamic_ki用于动态调整积分增益，使积分增益随着误差的大小而变化，以提高积分稳定性，但是会出现积分积不上去的情况
//changing_integration_rate用于在积分增益过大或过小时，自动调整积分增益，以防止积分过大或过小，调的参数过多用了dynamic_ki再说

// 限幅函数
static float limit_max(float value, float max) {
    if (value > max) return max;
    if (value < -max) return -max;
    return value;
} 
//梯形计算
static void Trapezoidal_integral(PID_init *pid){
    pid->data.trapezoid = (pid->data.err[0] + pid->data.err[1] ) / 2.0f;
}

//微分先行计算推荐和滤波一起使用算法也是塞在一起用的
//扔掉目标信号的微分，只保留输入（测量值）的微分
static void Derivative_on_measurement(PID_init *pid){
    pid->data.dbuff[2] = pid->data.dbuff[1];
    pid->data.dbuff[1] = pid->data.dbuff[0];
    pid->data.dbuff[0] = pid->data.last_measured - pid->data.measured;
}

//微分滤波计算使用算法也是塞在一起用的
static void Derivative_filter(PID_init *pid){
    //alpha越大，滤波具有更快的动态性能，但是噪声也会加大，alpha越小，滤波后的值更平滑，但是动态性能差
    pid->data.dbuff[0] = pid->alpha * pid->data.dbuff[0]  + (1.0f - pid->alpha) * pid->data.dbuff[1];
}

//变速积分计算
static void Changing_Integration_Rate(PID_init *pid){
    //由于强制使用梯形积分，所以使用trapezoid代指iout
    //未来如果除梯形积分外，还需增加其他积分方式，则需修改此处代码，bool
    float integral_base = pid->data.trapezoid * pid->ki;
    if(pid->data.err[0] * pid->data.iout > 0) //误差与积分方向相同
    {
        if(fabsf(pid->data.err[0]) <= pid->cofB)
            pid->data.iout += integral_base;  // 正常积分
        else if(fabsf(pid->data.err[0]) <= pid->cofA + pid->cofB){
            float rate = (pid->cofA - fabsf(pid->data.err[0]) + pid->cofB) / pid->cofA; //看王洪玺和B站视频来自己定参数
            //0<rate<1,rate越接近1，积分增益越大
            pid->data.iout += integral_base * rate; 
        }
        else{
            integral_base = 0.0f; //积分过大，停止积分
            pid->data.iout += integral_base;//保持上一次积分输出
        }   
    } 
    else {
        pid->data.iout += integral_base;  // 误差与积分方向相反，正常积分
    }
}

//动态积分
static void Dynamic_integral(PID_init *pid){
    pid->dynamic_ki = pid->ki / (1 + fabsf(pid->data.err[0]) );
    pid->data.iout += pid->dynamic_ki * pid->data.trapezoid;
    pid->data.iout = limit_max(pid->data.iout, pid->max_iout);
}

/**
 * @brief PID实例初始化函数 
 * @note 实例化PID结构体，设置PID参数，初始化PID数据结构
 * @param pid 实例指针
 * @param kp 比例增益
 * @param ki 积分增益
 * @param kd 微分增益
 * @param max_out 输出限幅
 * @param max_iout 积分限幅
 * @param alpha 微分滤波系数
 * @param cofA 变速积分参数A
 * @param cofB 变速积分参数B
 * @param Changing_Integration_Rate bool开关变速积分
 * @param Dynamic_integral 开关动态积分
 * @param Derivative_On_Measurement 开关微分先行
 * @param Derivative_Filtering 开关微分滤波
 */
void PID_Init(PID_init *pid, float kp, float ki, float kd,
 float max_out, float max_iout,
 float alpha,float cofA,float cofB,
 bool Changing_Integration_Rate,bool Dynamic_integral,
 bool Derivative_On_Measurement){
    pid->kp = kp;
    pid->ki = ki;
    pid->kd = kd;
    pid->max_out = max_out;
    pid->max_iout = max_iout;
    pid->alpha = alpha;
    pid->cofA = cofA;    //变速积分参数A
    pid->cofB = cofB;    //变速积分参数B
    pid->Dynamic_integral = Dynamic_integral; //使用动态积分
    pid->Changing_Integration_Rate = Changing_Integration_Rate;//使用变速积分
    pid->Derivative_On_Measurement = Derivative_On_Measurement; //使用微分先行
    pid->first_call = true; //第一次调用标志
    
    pid->data.pout = 0.0f;
    pid->data.iout = 0.0f;
    pid->data.dout = 0.0f;
    pid->data.trapezoid = 0.0f;
    pid->data.last_measured = 0.0f;
    pid->data.measured = 0.0f;
    pid->dynamic_ki = 0.0f;

    for (uint8_t i = 0; i < 3; i++)
    {
        pid->data.dbuff[i] = 0.0f;
        pid->data.err[i] = 0.0f;
    }
    
 }

/**
 * @brief PID计算函数
 * @param pid 实例指针
 * @param set 设定值
 * @param measured 测量值
 * @return pid输出值
 */
float PID_clac(PID_init *pid,float set,float measured){ 
    if(pid->first_call) {
        pid->data.measured = measured;
        pid->data.last_measured = measured;
        pid->first_call = false;
    }
    pid->data.set = set;
    pid->data.last_measured = pid->data.measured;
    pid->data.measured = measured;

    pid->data.err[2] = pid->data.err[1];
    pid->data.err[1] = pid->data.err[0];
    pid->data.err[0] = pid->data.set - pid->data.measured;
    if(pid->Derivative_On_Measurement) //使用微分先行和滤波
    { Derivative_on_measurement(pid);
      Derivative_filter(pid);}  
    
    pid->data.pout = pid->kp * pid->data.err[0];
    if(pid->Derivative_On_Measurement) //使用微分先行和滤波
        pid->data.dout = pid->kd * pid->data.dbuff[0];
    else
        pid->data.dout = pid->kd * (pid->data.err[0] - pid->data.err[1]);
    Trapezoidal_integral(pid); //计算梯形面积
    if (pid->Dynamic_integral) //使用动态积分
        Dynamic_integral(pid);
    else if (pid->Changing_Integration_Rate){//使用变速积分
        Changing_Integration_Rate(pid);
        pid->data.iout = limit_max(pid->data.iout, pid->max_iout);
    }
    else{
        pid->data.iout += pid->ki * pid->data.trapezoid; //计算积分
        pid->data.iout = limit_max(pid->data.iout, pid->max_iout);
    }
    pid->out = limit_max(pid->data.pout + pid->data.iout + pid->data.dout, pid->max_out);

    return pid->out;
}
