#ifndef _PID_H_
#define _PID_H_

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h> 
#include <stdbool.h>
#include <math.h>
#include "arm_math.h"

typedef enum
{
    PID_OK = 1,
    PID_LOCK_ERROR = 2, //电机堵转
} ErrorType_e;

#pragma pack(push, 1) // 开始1字节对齐
typedef struct
{
    uint64_t ERRORCount;
    ErrorType_e ERRORType;
} PID_ErrorHandler_t;
typedef struct
{
    float set;
    float measured;
    float last_measured;
    float pout;
    float iout;
    float dout;
    float err[3];
    float dbuff[3];
    float trapezoid;
}PID_data;
typedef struct
{
    float kp;
    float ki;
    float kd;
    float out;
    float max_out;   // 输出限幅
    float max_iout;  // 积分最大输出
    float alpha;     //微分滤波系数
    float cofA;      //变速积分参数A
    float cofB;      //变速积分参数B
    float dynamic_ki; //动态积分
    bool Changing_Integration_Rate; //变速积分
    bool Dynamic_integral; //动态积分
    bool Derivative_On_Measurement; //微分先行（微分在测量上）和滤波
    bool first_call; //第一次调用标志
    PID_data data;
    PID_ErrorHandler_t ERRORHandler;
}PID_init;
#pragma pack(pop) // 恢复默认对齐

extern void PID_Init(PID_init *pid, float kp, float ki, float kd,
 float max_out, float max_iout,
 float alpha,float cofA,float cofB,
 bool Changing_Integration_Rate,bool Dynamic_integral,
 bool Derivative_On_Measurement);

extern float PID_clac(PID_init *pid,float set,float measured);

#endif