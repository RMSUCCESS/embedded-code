1.使用

请优先初始化pid结构体

 PID_Init初始化参数 bool开关算法，以实现效果优先，当调试的参数无法满足要求，再增加算法处理。

**important :请优先了解算法作用再使用**

通过附件参考资料，详细的了解。

如图

![](C:\Users\Administrator\AppData\Roaming\marktext\images\2025-10-20-14-21-46-image.png)

pid clac 

![](C:\Users\Administrator\AppData\Roaming\marktext\images\2025-10-20-14-22-26-image.png)调用就是这么简单

完整过程

#include "PID.h"

int main() {
    // 1. 声明并初始化PID结构体
    PID_init motor_pid;

    // 参数配置示例（具体参数需要根据实际系统调试）
        2.5f,   // Kp
        0.1f,   // Ki 
        0.05f,  // Kd
        500.0f, // 最大输出限制
        300.0f, // 积分限幅
        0.2f,   // 微分滤波系数α
        20.0f,  // 变速积分参数A
        5.0f,   // 变速积分参数B
        true,   // 启用变速积分
        false,  // 禁用动态积分
        true    // 启用微分先行
    );
    
    // 2. 控制循环示例
    float setpoint = 100.0f;   // 目标值
    float measured = 0.0f;     // 实际测量值（来自传感器）
    float output = 0.0f;       // 控制器输出
    
    while(1) {
        // 获取当前测量值（示例中简化处理）
        measured = get_sensor_value();
    
        // 3. 执行PID计算
        output = PID_clac(&motor_pid, setpoint, measured);
    
        // 4. 应用输出到执行器
        set_motor_power(output);
    
    }
    
    return 0;

}上述函数参数是AI写的没工程价值



附件

参考资料

微分先行

[PID库与PID基本优化（二） - WangHongxi - 博客园](https://www.cnblogs.com/WangHongxi/p/12405456.html)

[微分先行PID控制算法及仿真-CSDN博客](https://blog.csdn.net/weixin_56691527/article/details/128764478?ops_request_misc=%257B%2522request%255Fid%2522%253A%2522d783e5e7a928b7390791b2c480576f7a%2522%252C%2522scm%2522%253A%252220140713.130102334..%2522%257D&request_id=d783e5e7a928b7390791b2c480576f7a&biz_id=0&utm_medium=distribute.pc_search_result.none-task-blog-2~all~top_click~default-1-128764478-null-null.142^v102^pc_search_result_base2&utm_term=%E5%BE%AE%E5%88%86%E5%85%88%E8%A1%8Cpid&spm=1018.2226.3001.4187)了解

微分滤波

[(4 封私信 / 57 条消息) 滤波器篇（一）：一阶低通滤波器 - 知乎](https://zhuanlan.zhihu.com/p/719635620)

[alpha-beta filter αβ滤波器_alpha滤波-CSDN博客](https://blog.csdn.net/zhoupian/article/details/90256065)

[在PID控制中添加低通滤波器的深度解析：从理论到工程实践_pid整定方法加低通滤波器-CSDN博客](https://blog.csdn.net/weixin_45813121/article/details/149025565)

变速积分

[PID库与PID基本优化（三） - WangHongxi - 博客园](https://www.cnblogs.com/WangHongxi/p/12409382.html)

[什么是变速积分PID【目前最简单最实用的PID教程】第六讲_哔哩哔哩_bilibili](https://www.bilibili.com/video/BV1GL411z7wn/?spm_id_from=333.1387.collection.video_card.click&vd_source=4191078f3b541c661b3c1f519565bce7)


