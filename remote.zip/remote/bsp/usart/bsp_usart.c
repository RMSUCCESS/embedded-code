/**
 * @file bsp_usart.c
 * @author neozng
 * @brief  串口bsp层的实现
 * @version beta
 * @date 2022-11-01
 *
 * @copyright Copyright (c) 2022
 *
 */
#include "bsp_usart.h"
//#include "bsp_log.h"
#include "stdlib.h"
#include "string.h"

extern UART_HandleTypeDef huart1;
extern DMA_HandleTypeDef hdma_usart1_tx;

/* usart service instance, modules' info would be recoreded here using USARTRegister() */
/* usart服务实例,所有注册了usart的模块信息会被保存在这里 */
static uint8_t idx;														 //  串口实例索引
static USARTInstance *usart_instance[DEVICE_USART_CNT] = {NULL};		 //  串口实例数组指针

/**
 * @brief 启动串口服务,会在每个实例注册之后自动启用接收,当前实现为DMA接收,后续可能添加IT和BLOCKING接收
 *
 * @todo 串口服务会在每个实例注册之后自动启用接收,当前实现为DMA接收,后续可能添加IT和BLOCKING接收
 *       可能还要将此函数修改为extern,使得module可以控制串口的启停
 *
 * @param _instance instance owned by module,模块拥有的串口实例
 */
void USARTServiceInit(USARTInstance *_instance)
{
    HAL_UARTEx_ReceiveToIdle_DMA(_instance->usart_handle, _instance->recv_buff, _instance->recv_buff_size);
    // 关闭dma half transfer中断防止两次进入HAL_UARTEx_RxEventCallback()
    // 这是HAL库的一个设计失误,发生DMA传输完成/半完成以及串口IDLE中断都会触发HAL_UARTEx_RxEventCallback()
    // 我们只希望处理第一种和第三种情况,因此直接关闭DMA半传输中断
    __HAL_DMA_DISABLE_IT(_instance->usart_handle->hdmarx, DMA_IT_HT);
}

USARTInstance *USARTRegister(USART_Init_Config_s *init_config)				//注册串口示例
{
    if (idx >= DEVICE_USART_CNT) {											// 超过最大实例数
        while (1){															//  无限循环，持续输出错误日志
          ;  //LOGERROR("[bsp_usart] USART exceed max instance count!");
				}
			}
    for (uint8_t i = 0; i < idx; i++) {										// 检查是否已经注册过
        if (usart_instance[i]->usart_handle == init_config->usart_handle){
            while (1){														//  如果发现重复注册，则进入死循环并记录错误日志
               ; //LOGERROR("[bsp_usart] USART instance already registered!");
						}
					}
				}
    USARTInstance *instance = (USARTInstance *)malloc(sizeof(USARTInstance));   //  为USART实例分配内存
    memset(instance, 0, sizeof(USARTInstance)); 								//  将分配的内存区域清零
																				//  初始化USART实例的各个参数
    instance->usart_handle = init_config->usart_handle; 						//  设置USART句柄
    instance->recv_buff_size = init_config->recv_buff_size; 					//  设置接收缓冲区大小
    instance->module_callback = init_config->module_callback; 					//  设置模块回调函数

    usart_instance[idx++] = instance; 											//  将实例保存到实例数组中，并增加索引
    USARTServiceInit(instance); 												//  初始化USART服务
    return instance; 															//  返回创建的USART实例
}

/* @todo 当前仅进行了形式上的封装,后续要进一步考虑是否将module的行为与bsp完全分离 */
void USARTSend(USARTInstance *_instance, uint8_t *send_buf, uint16_t send_size, USART_TRANSFER_MODE mode)
{
    switch (mode) 																							//  根据不同的传输模式选择相应的串口发送方式
    {
    case USART_TRANSFER_BLOCKING: 																			//  阻塞模式发送：等待数据发送完成，超时时间为100ms
        HAL_UART_Transmit(_instance->usart_handle, send_buf, send_size, 100);
        break;
    case USART_TRANSFER_IT: 																				//  中断模式发送：启动发送后立即返回，通过中断完成数据发送
        HAL_UART_Transmit_IT(_instance->usart_handle, send_buf, send_size);
        break;
    case USART_TRANSFER_DMA:																				//  DMA模式发送：使用DMA控制器进行数据发送，减少CPU负担
        HAL_UART_Transmit_DMA(_instance->usart_handle, send_buf, send_size);
        break;
    default: 																								//  默认情况：处理非法模式
        while (1)
					;						// illegal mode! check your code context! 检查定义instance的代码上下文,可能出现指针越界
        break;
    }
}

/* 串口发送时,gstate会被设为BUSY_TX */
uint8_t USARTIsReady(USARTInstance *_instance)											//检查指定的USART实例是否准备好进行数据传输
{
    if (_instance->usart_handle->gState | HAL_UART_STATE_BUSY_TX)						//  检查USART状态是否为忙（发送中）
        return 0; 																		//  返回0表示条件不满足或操作失败
    else
        return 1; 																		//  返回1表示条件满足或操作成功
}

/**
 * @brief 每次dma/idle中断发生时，都会调用此函数.对于每个uart实例会调用对应的回调进行进一步的处理
 *        例如:视觉协议解析/遥控器解析/裁判系统解析
 *
 * @note  通过__HAL_DMA_DISABLE_IT(huart->hdmarx,DMA_IT_HT)关闭dma half transfer中断防止两次进入HAL_UARTEx_RxEventCallback()
 *        这是HAL库的一个设计失误,发生DMA传输完成/半完成以及串口IDLE中断都会触发HAL_UARTEx_RxEventCallback()
 *        我们只希望处理，因此直接关闭DMA半传输中断第一种和第三种情况
 *
 * @param huart 发生中断的串口
 * @param Size 此次接收到的总数居量,暂时没用
 */
//void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
//{
//     for (uint8_t i = 0; i < idx; ++i) //  遍历所有已注册的USART实例
//    { // find the instance which is being handled
//        if (huart == usart_instance[i]->usart_handle) 											//  判断当前串口句柄是否与实例中的串口句柄匹配
//        { // call the callback function if it is not NULL
//            if (usart_instance[i]->module_callback != NULL)										//  检查当前USART实例的回调函数是否已设置
//            {
//                usart_instance[i]->module_callback();												//  如果回调函数存在，则执行该回调函数
//                memset(usart_instance[i]->recv_buff, 0, Size); 									// 接收结束后清空buffer,对于变长数据是必要的
//            }
//            HAL_UARTEx_ReceiveToIdle_DMA(usart_instance[i]->usart_handle, 				 		//  启动DMA空闲中断接收，将接收到的数据存入接收缓冲区
//						usart_instance[i]->recv_buff, usart_instance[i]->recv_buff_size);    	  	//  参数：串口句柄、接收缓冲区指针、接收缓冲区大小
//            __HAL_DMA_DISABLE_IT(usart_instance[i]->usart_handle->hdmarx, DMA_IT_HT); 			//  禁用DMA半传输中断，只使用传输完成中断 
//																									//参数：DMA句柄、要禁用的中断类型(DMA_IT_HT表示半传输中断)
//            return; // break the loop
//        }
//    }
//}
void uart_receive_handler(UART_HandleTypeDef *huart)												//一个汇总,其余串口直接引用
{
	 for (uint8_t i = 0; i < idx; ++i) //  遍历所有已注册的USART实例
    { // find the instance which is being handled
        if (huart == usart_instance[i]->usart_handle) 												//  判断当前串口句柄是否与实例中的串口句柄匹配
        { // call the callback function if it is not NULL
            if (usart_instance[i]->module_callback != NULL)											//  检查当前USART实例的回调函数是否已设置
            {
                usart_instance[i]->module_callback();												//  如果回调函数存在，则执行该回调函数
                memset(usart_instance[i]->recv_buff, 0, usart_instance[i]->recv_buff_size);			// 接收结束后清空buffer,对于变长数据是必要的
            }
            HAL_UARTEx_ReceiveToIdle_DMA(usart_instance[i]->usart_handle, 				 			//  启动DMA空闲中断接收，将接收到的数据存入接收缓冲区
						usart_instance[i]->recv_buff, usart_instance[i]->recv_buff_size);    	  	//  参数：串口句柄、接收缓冲区指针、接收缓冲区大小
            __HAL_DMA_DISABLE_IT(usart_instance[i]->usart_handle->hdmarx, DMA_IT_HT); 				//  禁用DMA半传输中断，只使用传输完成中断 
																									//参数：DMA句柄、要禁用的中断类型(DMA_IT_HT表示半传输中断)
            return; // break the loop
        }																																					
    }
}

/**
 * @brief 当串口发送/接收出现错误时,会调用此函数,此时这个函数要做的就是重新启动接收
 *
 * @note  最常见的错误:奇偶校验/溢出/帧错误
 *
 * @param huart 发生错误的串口
 */
void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)    //自动调用
{
    for (uint8_t i = 0; i < idx; ++i) 												//  遍历所有串口实例，查找发生错误的串口
    {
        if (huart == usart_instance[i]->usart_handle) 								//  检查当前遍历的串口句柄是否与发生错误的串口句柄匹配
        {
            HAL_UARTEx_ReceiveToIdle_DMA(usart_instance[i]->usart_handle, usart_instance[i]->recv_buff, usart_instance[i]->recv_buff_size);
            __HAL_DMA_DISABLE_IT(usart_instance[i]->usart_handle->hdmarx, DMA_IT_HT); //  禁用DMA半传输中断，避免不必要的触发
            //LOGWARNING("[bsp_usart] USART error callback triggered, instance idx [%d]", i); //  记录错误日志，输出发生错误的串口实例索引
            return;																										//  找到匹配的串口后，直接返回，结束函数执行
        }
    }
}
