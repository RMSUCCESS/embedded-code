#include "bsp_log.h"
#include <string.h>

// 定义错误标志数组
uint8_t error_flags[ERR_COUNT] = {0};

// 初始化错误系统
void Error_Init(void) {
    memset(error_flags, 0, sizeof(error_flags));
}

// 清除所有错误
void Error_Clear(void) {
    memset(error_flags, 0, sizeof(error_flags));
}

// 检查是否有任何错误
uint8_t Error_Check(void) {
    for(int i = 0; i < ERR_COUNT; i++) {
        if(error_flags[i]) {
            return 1;
        }
    }
    return 0;
}
