# bsp_log

有三个函数`void Error_Init(void)`（初始化）`void Error_Clear(void)`（清除所有错误标志）`uint8_t Error_Check(void)`（检查错误），且有三个直接对数组进行操作的宏定义，如下

```
#define SET_ERROR(id)     error_flags[id] = 1
#define CLEAR_ERROR(id)   error_flags[id] = 0
#define CHECK_ERROR(id)   error_flags[id]
```

id由枚举变量设定

```
typedef enum {
    ERR_NONE = 0,
    ERR_SENSOR,       //传感器错误
    ERR_COMM,         //通信错误
    ERR_POWER,        //电源错误
    ERR_MEMORY,       //内存错误
    ERR_COUNT         // 用于定义错误数量
} ErrorType;
```

需要详细错误标志或更多，直接在ERR_COUNT之上增加，设置错误标志操作为`SET_ERROR(id)`，清除单个错误标志操作为`CLEAR_ERROR(id)`，检查错误标志为`CHECK_ERROR(id)`。

付明扬    q3590079923
