#ifndef BSP_LOG_H
#define BSP_LOG_H

#include <stdint.h>

// 错误类型枚举
typedef enum {
    ERR_NONE = 0,
    ERR_SENSOR,   //传感器错误
    ERR_COMM,			//通信错误
    ERR_POWER,		//电源错误
    ERR_MEMORY,		//内存错误
    ERR_COUNT 	  // 用于定义错误数量
} ErrorType;

// 声明外部数组
extern uint8_t error_flags[ERR_COUNT];

// 设置错误（直接操作数组）
#define SET_ERROR(id)     error_flags[id] = 1
#define CLEAR_ERROR(id)   error_flags[id] = 0
#define CHECK_ERROR(id)   error_flags[id]

void Error_Init(void);
void Error_Clear(void);
uint8_t Error_Check(void);

#endif
